const instance = require('./instance');

const ins1 = () => {
  console.log("Ins1")
  instance.doSomething()

  instance.printMC();
}

module.exports = {
  ins1
}