const MyClass = require('./myClass');

const mc = new MyClass();

const doSomething = () => {
  mc.myVar1 ++;
  mc.myVar2 --;
}

const printMC = () => {
  console.log(mc.myVar1, mc.myVar2);
}

module.exports = {
  doSomething,
  printMC
}