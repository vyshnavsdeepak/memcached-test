const instance = require('./instance');

const ins2 = () => {
  console.log("Ins2")
  instance.doSomething()

  instance.printMC();
}

module.exports = {
  ins2
}