const MyClass = class {
  constructor() {
    this.myVar1 = 0;
    this.myVar2 = 10;
  }
}

module.exports = MyClass;