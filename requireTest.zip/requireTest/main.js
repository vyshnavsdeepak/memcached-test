const inr1 = require('./instanceRequire1');
const inr2 = require('./instanceRequire2');

inr1.ins1();

inr2.ins2();